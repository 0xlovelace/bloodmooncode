#!/bin/bash

# This bash script will run exactly needed to install the python module for you to run cryptio

sudo pip install crypto